var hostname = '192.168.0.200'
var namespace = '/rbkairos'
var map_frame = 'rbkairos_map'
var map_topic = namespace+'/map'
var has_camera = false
